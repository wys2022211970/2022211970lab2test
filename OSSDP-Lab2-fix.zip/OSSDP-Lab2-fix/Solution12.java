package com.example.lab2codes;
/*
 * @Description:
 * ## 字符串相乘
 * 给定两个以字符串形式表示的非负整数 num1 和 num2，返回 num1 和 num2 的乘积，它们的乘积也表示为字符串形式。
 * 注意：不能使用任何内置的 BigInteger 库或直接将输入转换为整数。
 *
 *  示例 1:
 *  输入: num1 = "2", num2 = "3"
 * 输出: "6"
 *
 * 示例 2:
 * 输入: num1 = "123", num2 = "456"
 * 输出: "56088"
 *
 */

class Solution {
    public String multiply(String num1, String num2) {
        //0×?结果为0
        if (num1.equals("0") || num2.equals("0")) {
            return "0";
        }

        String ans = "0";
        int m = num1.length(), n = num2.length();
        for (int i = n - 1; i >= 0; i--) {
            StringBuilder curr = new StringBuilder();
            int add = 0;
            for (int j = n - 1; j > i; j--) {
                curr.append(0);
            }
            int y = num2.charAt(i) - '0';
            for (int j = m - 1; j >= 0; j--) {
                int x = num1.charAt(j) - '0';
                int product = x * y + add;
                curr.append(product % 10);
                add = product / 10;
            }
            if (add != 0) {
                curr.append(add);
            }
            ans = addStrings(ans, curr.reverse().toString());
        }
        return ans;
    }

    public String addStrings(String num1, String num2) {
        int i = num1.length() - 1, j = num2.length() - 1, add = 0;
        StringBuffer ans = new StringBuffer();
        while (i >= 0 || j >= 0 || add != 0) {
            int x = i >= 0 ? num1.charAt(i) - '0' : 0;
            int y = j >= 0 ? num2.charAt(j) - '0' : 0;
            int result = x + y + add;
            ans.append(result % 10);
            add = result / 10;
            i--;
            j--;
        }
        ans.reverse();
        return ans.toString();
    }
}

package com.example.lab2codes;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class L2022211968_12_Test {
    @Test
    public void testMultiply_ValidInputs() {
        Solution solution = new Solution();
        assertEquals("6", solution.multiply("2", "3"));
        assertEquals("56088", solution.multiply("123", "456"));
    }

    @Test
    public void testMultiply_ZeroInput() {
        Solution solution = new Solution();
        assertEquals("0", solution.multiply("0", "5"));
        assertEquals("0", solution.multiply("5", "0"));
        assertEquals("0", solution.multiply("0", "0"));
    }

    @Test
    public void testMultiply_LargeNumbers() {
        Solution solution = new Solution();
        assertEquals("1000000", solution.multiply("1000", "1000"));
    }
}
